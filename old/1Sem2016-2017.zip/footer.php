<footer>
            <div class="container section">
                <h1>Contact Us</h1>
                <div class="contact">
                    <div>
                        For any questions and/or concerns, feel free to reach us through the following online channels:
                        <div class="socialicon">
                            <a href="https://www.facebook.com/RegComHelpdesk"><i class="fa fa-facebook-square fa-5x"></i></a>
                            <a href="https://twitter.com/AteneoRegcom"><i class="fa fa-twitter-square fa-5x"></i></a>
                        </div>
                        You may also visit the RegCom promo boards along the EDSA Walk.
                        <br><br>
                        Room 209 2nd Floor
                        <br>
                        Manuel V. Pangilinan Center for Student Leadership,
                        <br>
                        Ateneo de Manila University
                        <br>
                        Katipunan Avenue,
                        Loyola Heights, Quezon City 
                    </div>
                    <div>
                        <strong>Office of the Registrar</strong><br>
                        426-6001 loc. 5130-5136
                        <br><br>
                        <strong>Office of the Associate Dean for Graduate Programs</strong><br>
                        426-6001 loc. 5141-5142
                        <br><br>
                        <strong>Office of the Associate Dean for Academic Affairs</strong><br>
                        426-6001 loc. 5011-5012
                        <br><br>
                        <strong>Office for Student Services</strong><br>
                        426-6001 loc. 5020, 5021
                        <br><br>
                        <strong>Office of Admission and Aid</strong><br>
                        426-6001 loc. 5154 – 5155
                    </div>
                </div>
                <a href="suggest.php"><button>Suggestion Box</button></a>
                <div class="copyright">Ateneo Registration Committee. Copyright 2015 All Rights Reserved.</div>
            </div>
        </footer>
    </body>
</html>