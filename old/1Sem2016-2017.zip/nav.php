<script>
    $(function() {
        $("#liprocedure").attr('class', 'active');
    });
</script>
        <div class="option wrap">Options</div>
        <div id="accordion">
            <h3>Undergraduates</h3>
            <div>
                <ul>
                    <a href="procedure.php"><li id="liunderg">Undergraduates</li></a>
                    <a href="newundergrad.php"><li id="lifresh">Freshmen and Transferees</li></a>
                    <a href="undergradintl.php"><li id="liintl">International Exchange Students</li></a>
                    <a href="lateundergrad.php"><li id="lilatefine">Late Registration w/ Fine</li></a>
                </ul>
            </div>
            <h3>Graduates</h3>
            <div>
                <ul>
                    <a href="oldgrad.php"><li id="lioldg">Old Graduates</li></a>
                    <a href="newgrad.php"><li id="linewg">New Graduates</li></a>
                    <a href="auditcross.php"><li id="liaudcross">Auditors and Cross Registrants</li></a>
                    <a href="lategrad.php"><li id="lilate">Late Registration w/ Fine</li></a>
                </ul>
            </div>
            <h3>Payment</h3>
            <div>
                <ul>
                    <a href="paymentdetails.php"><li id="lioncamp">On-campus Payment</li></a>
                    <a href="payment.php"><li id="lioffcamp">Off-campus Payment</li></a>
                </ul>
            </div>
            <h3>Downloads</h3>
            <div>
                <ul>
                    <a href="downloads.php"><li id="lidoc">Documents</li></a>
                    <a href="files/proxyletter.docx"><li id="liauthletter">Sample Authorization Letter</li></a>
                </ul>
            </div>
            <h3>Others</h3>
            <div>
                <ul>
                    <a href="proxy.php"><li id="liproxy">Proxy Guidelines</li></a>
                    <a href="loadrev.php"><li id="liloadrev">Load Revision Schedule</li></a>
                    <a href="map.php"><li id="limap">Campus Map</li></a>
                </ul>
            </div>
        </div>