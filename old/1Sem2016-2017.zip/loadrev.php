<?php $accordionhtml = "$( '#accordion' ).accordion({active: 4});" ?>

<?php include('header.php') ?>
<?php include('nav.php') ?>
<?php         
    $file_handle = fopen("vars.txt", "r");
    $result = array();
    while (!feof($file_handle) ) {
        $line_of_text = fgets($file_handle);
        $parts = explode(':', trim($line_of_text), 2);
        ${strtolower($parts[0])} = trim($parts[1]);
    }

    fclose($file_handle);
?>
<script>
    $(function() {
        $("#liloadrev").attr('class', 'sideactive');
    });
</script>


<div id="procedure" class="section wrap" style="min-height: 80vh;">
            <h1 style="margin-bottom: 0;">Load Revision Schedule</h1>
            <p><center style="margin-bottom: 24px;">First Semester (2016 - 2017)</center></p>
            <div class="nonsteps">
            <div class="tablecontain">
                <table class="loadrev">
                    <tbody>
                    <h2>Load Revision Form</h2>
                        <tr>
                            <td style="padding-top: 24px;" class="subtitle">August 13</td>
                            <td style="padding-top: 24px;" class="subtitle">Saturday</td>
                        </tr>
                        <tr>
                            <td>
                                <span class="underline">Time:</span><br>
                                8:00 am - 12:00 nn<br><br>
                                <span class="underline">Venue:</span><br>
                                <?php echo $loadrevvenue ?>
                            </td>
                            <td>
                                <strong>Load Revision forms are now available in your AISIS account</strong><br>
                                Deadline of the submission of completed load revision form for undergraduate and graduate students<br>
                                <div class="indent">
                                    - Change/Addition of subject(s)<br>
                                    - Change of section<br>
                                    - Change of subject from audit to credit<br>
                                    - Change of concentration/ degree programs
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td style="padding-top: 24px;" class="subtitle">September 17</td>
                            <td  style="padding-top: 24px;" class="subtitle">Saturday</td>
                        </tr>
                        <tr>
                            <td>
                                <span class="underline">Time:</span><br>
                                8:00 am - 12:00 nn <br><br>
                                <span class="underline">Venue:</span><br>
                                <?php echo $loadrevvenue ?>
                            </td>
                            <td>
                                Deadline of the submission of completed load revision form for undergraduate and graduate students<br>
                                <div class="indent">
                                    - Withdrawal from subject(s)<br>
                                    - Change of subject from credit to audit
                                </div>
                               
                            </td>
                        </tr>
                    </tbody>
                </table>
                
                <table class="loadrev">
                    <tbody>
                        <h2>Form for Change of Degree Program or Application for Minor/Specialization</h2>
                        <tr>
                            <td style="padding-top: 24px;" class="subtitle">August 13</td>
                            <td style="padding-top: 24px;" class="subtitle">Saturday</td>
                        </tr>
                        <tr>
                            <td>
                                <span class="underline">Time:</span><br>
                                8:00 am - 12:00 nn<br><br>
                                <span class="underline">Venue:</span><br>
                                <?php echo $loadrevvenue ?>
                            </td>
                            <td>
                                Deadline of the submission of completed load revision form for undergraduate and graduate students<br>
                                <div class="indent">
                                    - Change of degree program
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <h4>*Note : There is no deadline for application of minor/specialization </h4><br><br>
            <p class="detail" style="width: 80%">Load revision forms can be obtained from your AISIS Account. However, <strong>the processing of these load revision forms can only be done once the Intersession Semester has begun.</strong></p>
        </div>
            <a href="map.html" class="next">Campus Map ></a>
            <div style="clear:both;"></div>
        </div>


<?php include('footer.php') ?>